import { useState, useEffect } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Employee {
  id: string;
  name: string;
  company_id: string;
}

interface Company {
  id: string;
  daily_rate: number;
  overtime_rate: number;
}

export default function Timesheet() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    employee_id: "",
    work_date: new Date().toISOString().split("T")[0],
    entry_time: "07:00",
    exit_time: "17:00",
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    const { data, error } = await supabase
      .from("employees")
      .select("*")
      .order("name");

    if (error) {
      toast({
        title: "Erro ao carregar funcionários",
        description: error.message,
        variant: "destructive",
      });
    } else {
      setEmployees(data || []);
    }
  };

  const getDayOfWeek = (date: string): number => {
    return new Date(date).getDay();
  };

  const getStandardMinutes = (dayOfWeek: number): number => {
    // 0 = Sunday, 1-4 = Mon-Thu, 5 = Friday, 6 = Saturday
    if (dayOfWeek >= 1 && dayOfWeek <= 4) {
      return 528; // 8h48min
    } else if (dayOfWeek === 5) {
      return 468; // 7h48min
    } else if (dayOfWeek === 6) {
      return 240; // 4h
    }
    return 0; // Sunday - no standard hours
  };

  const calculateTimesheet = (
    entryTime: string,
    exitTime: string,
    workDate: string,
    dailyRate: number,
    overtimeRate: number
  ) => {
    const [entryHour, entryMinute] = entryTime.split(":").map(Number);
    const [exitHour, exitMinute] = exitTime.split(":").map(Number);

    const entryMinutes = entryHour * 60 + entryMinute;
    const exitMinutes = exitHour * 60 + exitMinute;

    let workedMinutes = exitMinutes - entryMinutes;
    if (workedMinutes < 0) workedMinutes += 24 * 60;

    workedMinutes = Math.max(0, workedMinutes - 60);

    const dayOfWeek = getDayOfWeek(workDate);
    const standardMinutes = getStandardMinutes(dayOfWeek);

    const overtimeMinutes = Math.max(0, workedMinutes - standardMinutes);
    const dailyValue = dailyRate;
    const overtimeValue = (overtimeMinutes / 60) * overtimeRate;
    const totalValue = dailyValue + overtimeValue;

    return {
      worked_minutes: workedMinutes,
      overtime_minutes: overtimeMinutes,
      daily_value: dailyValue,
      overtime_value: overtimeValue,
      total_value: totalValue,
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Get employee and company data
    const { data: employee, error: employeeError } = await supabase
      .from("employees")
      .select("company_id")
      .eq("id", formData.employee_id)
      .single();

    if (employeeError) {
      toast({
        title: "Erro ao buscar funcionário",
        description: employeeError.message,
        variant: "destructive",
      });
      return;
    }

    const { data: company, error: companyError } = await supabase
      .from("companies")
      .select("daily_rate, overtime_rate")
      .eq("id", employee.company_id)
      .single();

    if (companyError) {
      toast({
        title: "Erro ao buscar empresa",
        description: companyError.message,
        variant: "destructive",
      });
      return;
    }

    const calculations = calculateTimesheet(
      formData.entry_time,
      formData.exit_time,
      formData.work_date,
      company.daily_rate,
      company.overtime_rate
    );

    const timesheetData = {
      employee_id: formData.employee_id,
      work_date: formData.work_date,
      entry_time: formData.entry_time,
      exit_time: formData.exit_time,
      ...calculations,
    };

    const { error } = await supabase
      .from("timesheet_entries")
      .upsert(timesheetData, {
        onConflict: "employee_id,work_date",
      });

    if (error) {
      toast({
        title: "Erro ao registrar ponto",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({ title: "Ponto registrado com sucesso!" });
      resetForm();
    }
  };

  const resetForm = () => {
    setFormData({
      employee_id: "",
      work_date: new Date().toISOString().split("T")[0],
      entry_time: "07:00",
      exit_time: "17:00",
    });
    setIsDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            Lançamento de Ponto
          </h1>
          <p className="text-muted-foreground">
            Registre entrada e saída de funcionários
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2" onClick={() => resetForm()}>
              <Plus className="h-4 w-4" />
              Registrar Ponto
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar Ponto</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="employee">Funcionário</Label>
                <Select
                  value={formData.employee_id}
                  onValueChange={(value) =>
                    setFormData({ ...formData, employee_id: value })
                  }
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um funcionário" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map((employee) => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="work_date">Data</Label>
                <Input
                  id="work_date"
                  type="date"
                  value={formData.work_date}
                  onChange={(e) =>
                    setFormData({ ...formData, work_date: e.target.value })
                  }
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="entry_time">Hora Entrada</Label>
                  <Input
                    id="entry_time"
                    type="time"
                    value={formData.entry_time}
                    onChange={(e) =>
                      setFormData({ ...formData, entry_time: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="exit_time">Hora Saída</Label>
                  <Input
                    id="exit_time"
                    type="time"
                    value={formData.exit_time}
                    onChange={(e) =>
                      setFormData({ ...formData, exit_time: e.target.value })
                    }
                    required
                  />
                </div>
              </div>
              <div className="bg-muted p-4 rounded-md text-sm">
                <p className="font-medium mb-2">Carga Horária Padrão:</p>
                <ul className="space-y-1 text-muted-foreground">
                  <li>Segunda a Quinta: 8h48min</li>
                  <li>Sexta-feira: 7h48min</li>
                  <li>Sábado: 4h</li>
                </ul>
                <p className="text-xs mt-2 text-amber-600 font-medium">
                  * 1 hora de almoço é automaticamente subtraída
                </p>
              </div>
              <div className="flex gap-2">
                <Button type="submit" className="flex-1">
                  Registrar
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={resetForm}
                  className="flex-1"
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-card p-6 rounded-lg border border-border">
        <p className="text-center text-muted-foreground">
          Use o botão "Registrar Ponto" para adicionar novos lançamentos.
          <br />
          Veja os registros e relatórios na aba "Relatórios".
        </p>
      </div>
    </div>
  );
}
