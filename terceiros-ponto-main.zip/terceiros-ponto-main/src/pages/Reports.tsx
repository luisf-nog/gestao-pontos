import { useState, useEffect } from "react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { FileDown, Calendar } from "lucide-react";
import * as XLSX from "xlsx";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface TimesheetEntry {
  id: string;
  work_date: string;
  entry_time: string;
  exit_time: string;
  worked_minutes: number;
  overtime_minutes: number;
  daily_value: number;
  overtime_value: number;
  total_value: number;
  employees: {
    name: string;
    companies: {
      name: string;
    };
  };
}

interface GroupedEntry {
  employeeName: string;
  companyName: string;
  entries: TimesheetEntry[];
  totalDaily: number;
  totalOvertime: number;
  totalValue: number;
}

export default function Reports() {
  const [entries, setEntries] = useState<TimesheetEntry[]>([]);
  const [startDate, setStartDate] = useState(
    new Date(new Date().getFullYear(), new Date().getMonth(), 1)
      .toISOString()
      .split("T")[0]
  );
  const [endDate, setEndDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const { toast } = useToast();

  useEffect(() => {
    fetchEntries();
  }, [startDate, endDate]);

  const fetchEntries = async () => {
    const { data, error } = await supabase
      .from("timesheet_entries")
      .select(
        `
        *,
        employees (
          name,
          companies (
            name
          )
        )
      `
      )
      .gte("work_date", startDate)
      .lte("work_date", endDate)
      .order("work_date", { ascending: true });

    if (error) {
      toast({
        title: "Erro ao carregar relatório",
        description: error.message,
        variant: "destructive",
      });
    } else {
      setEntries(data || []);
    }
  };

  const formatTime = (time: string) => {
    return time.substring(0, 5);
  };

  const formatMinutes = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    const sign = minutes < 0 ? "-" : "";
    return `${sign}${String(Math.abs(hours)).padStart(2, "0")}:${String(Math.abs(mins)).padStart(2, "0")}`;
  };

  const groupedEntries: GroupedEntry[] = entries.reduce(
    (acc: GroupedEntry[], entry) => {
      const employeeName = entry.employees.name;
      const existing = acc.find((g) => g.employeeName === employeeName);

      if (existing) {
        existing.entries.push(entry);
        existing.totalDaily += entry.daily_value;
        existing.totalOvertime += entry.overtime_value;
        existing.totalValue += entry.total_value;
      } else {
        acc.push({
          employeeName,
          companyName: entry.employees.companies.name,
          entries: [entry],
          totalDaily: entry.daily_value,
          totalOvertime: entry.overtime_value,
          totalValue: entry.total_value,
        });
      }

      return acc;
    },
    []
  );

  const exportToExcel = () => {
    const workbook = XLSX.utils.book_new();

    groupedEntries.forEach((group) => {
      const worksheetData = [
        [`Funcionário: ${group.employeeName}`],
        [`Empresa: ${group.companyName}`],
        [`Período: ${format(new Date(startDate), "dd/MM/yyyy")} a ${format(new Date(endDate), "dd/MM/yyyy")}`],
        [],
        ["Data", "Entrada", "Saída", "Horas Trab.", "Horas Extras", "Valor Diária", "Valor Extra", "Total"],
      ];

      group.entries.forEach((entry) => {
        worksheetData.push([
          format(new Date(entry.work_date), "dd/MM/yyyy"),
          formatTime(entry.entry_time),
          formatTime(entry.exit_time),
          formatMinutes(entry.worked_minutes),
          formatMinutes(entry.overtime_minutes),
          entry.daily_value,
          entry.overtime_value,
          entry.total_value,
        ]);
      });

      worksheetData.push([]);
      worksheetData.push([
        "", "", "", "", "TOTAIS:",
        group.totalDaily,
        group.totalOvertime,
        group.totalValue,
      ]);

      const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

      worksheet["!cols"] = [
        { width: 12 },
        { width: 10 },
        { width: 10 },
        { width: 12 },
        { width: 12 },
        { width: 15 },
        { width: 15 },
        { width: 15 },
      ];

      const sheetName = group.employeeName.substring(0, 31);
      XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
    });

    XLSX.writeFile(
      workbook,
      `relatorio_pontos_${format(new Date(), "yyyyMMdd_HHmmss")}.xlsx`
    );

    toast({
      title: "Relatório exportado",
      description: "O arquivo Excel foi baixado com sucesso!",
    });
  };

  const totalGeral = groupedEntries.reduce(
    (sum, group) => sum + group.totalValue,
    0
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Relatórios</h1>
          <p className="text-muted-foreground">
            Visualize e exporte relatórios de diárias e horas extras
          </p>
        </div>
        <Button
          onClick={exportToExcel}
          disabled={groupedEntries.length === 0}
          className="gap-2"
        >
          <FileDown className="h-4 w-4" />
          Exportar Excel
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Calendar className="h-5 w-5" />
            Período
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="start_date">Data Inicial</Label>
              <Input
                id="start_date"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="end_date">Data Final</Label>
              <Input
                id="end_date"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Total Geral</Label>
              <div className="h-10 px-3 flex items-center bg-slate-100 rounded-md border border-slate-200">
                <span className="text-2xl font-bold text-slate-900">
                  {totalGeral.toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  })}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {groupedEntries.map((group) => (
          <Card key={group.employeeName} className="overflow-hidden">
            <CardHeader className="bg-slate-900 text-white">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-xl">{group.employeeName}</CardTitle>
                  <p className="text-sm opacity-90 mt-1">{group.companyName}</p>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold">
                    {group.totalValue.toLocaleString("pt-BR", {
                      style: "currency",
                      currency: "BRL",
                    })}
                  </p>
                  <p className="text-xs opacity-75 mt-1">
                    {group.entries.length} {group.entries.length === 1 ? "dia" : "dias"}
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50">
                      <TableHead className="font-semibold">Data</TableHead>
                      <TableHead className="font-semibold">Entrada</TableHead>
                      <TableHead className="font-semibold">Saída</TableHead>
                      <TableHead className="font-semibold">Horas Trab.</TableHead>
                      <TableHead className="font-semibold">Extras</TableHead>
                      <TableHead className="font-semibold text-right">Diária</TableHead>
                      <TableHead className="font-semibold text-right">Extra</TableHead>
                      <TableHead className="font-semibold text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {group.entries.map((entry) => (
                      <TableRow key={entry.id} className="hover:bg-slate-50">
                        <TableCell className="font-medium">
                          {format(new Date(entry.work_date), "dd/MM/yyyy")}
                        </TableCell>
                        <TableCell className="text-slate-600">{formatTime(entry.entry_time)}</TableCell>
                        <TableCell className="text-slate-600">{formatTime(entry.exit_time)}</TableCell>
                        <TableCell className="font-mono">
                          {formatMinutes(entry.worked_minutes)}
                        </TableCell>
                        <TableCell>
                          <span
                            className={`font-mono ${
                              entry.overtime_minutes > 0
                                ? "text-green-600 font-semibold"
                                : entry.overtime_minutes < 0
                                  ? "text-red-600 font-semibold"
                                  : "text-slate-600"
                            }`}
                          >
                            {formatMinutes(entry.overtime_minutes)}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          {entry.daily_value.toLocaleString("pt-BR", {
                            style: "currency",
                            currency: "BRL",
                          })}
                        </TableCell>
                        <TableCell className="text-right">
                          <span
                            className={
                              entry.overtime_value > 0
                                ? "text-green-600 font-semibold"
                                : ""
                            }
                          >
                            {entry.overtime_value.toLocaleString("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            })}
                          </span>
                        </TableCell>
                        <TableCell className="text-right font-bold">
                          {entry.total_value.toLocaleString("pt-BR", {
                            style: "currency",
                            currency: "BRL",
                          })}
                        </TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="bg-slate-100 font-bold border-t-2 border-slate-300">
                      <TableCell colSpan={5} className="text-right text-slate-700">
                        TOTAIS
                      </TableCell>
                      <TableCell className="text-right">
                        {group.totalDaily.toLocaleString("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        })}
                      </TableCell>
                      <TableCell className="text-right text-green-600">
                        {group.totalOvertime.toLocaleString("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        })}
                      </TableCell>
                      <TableCell className="text-right text-slate-900 text-lg">
                        {group.totalValue.toLocaleString("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        })}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {groupedEntries.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-muted-foreground text-lg">
              Nenhum registro encontrado para o período selecionado.
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Selecione um período diferente ou registre novos pontos.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
